<div class="search__home__global__wrapper">
    <h1>Rechercher un avocat</h1>
    <div class="search__inputs__wrapper">
        <div class="input__wrapper">
            <input class ="input" type="text" name="name" id="name__search__input" placeholder="Nom de l'avocat">
            <div id="name__search__results"></div>
        </div>
        <div class="input__wrapper">
            <input class ="input" type="text" name="city" id="city__search__input" placeholder="Ville">
            <div id="city__search__results"></div>
        </div>
        <div class="input__wrapper">
            <input class ="input submit_input" type="submit" name="search" id="submit__search__input" value = "Rechercher"> 
        </div>
    </div>
</div>

<div id="lawyers__search__results__global__wrapper">
    
</div>