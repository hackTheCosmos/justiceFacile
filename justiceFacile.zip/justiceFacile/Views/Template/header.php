<header>
    <div class="top__header">
            <h1 class ='header__main__title'>Justice facile</h1>
            <i class="fa-solid fa-scale-balanced"></i>
        </div>
    <div class ="burger__header__wrapper">
       
    <div class="header__title__wrapper">      
        <h2 class ='header__second__title'>Annuaire</h2>
        <h2 class ='header__second__title'>des avocats</h2>
        <h2 class ='header__second__title'>et des barreaux</h2>
        <h2 class ='header__second__title'>français</h2>
       
    </div>
    <div class="burger__icon__wrapper">
        <i class="fa-solid fa-bars burger__icon"></i>
    </div>
</header>