<div class="mobile__nav__wrapper">

    <ul>
        <li>
            <i class="fa-solid fa-magnifying-glass"></i>
            <a href="index.php">rechercher un avocat</a>
        </li>
        <li>
            <i class="fa-solid fa-hotel"></i>
            <a href="index.php?page=bars">les barreaux français</a>
        </li>
    </ul>
</div>