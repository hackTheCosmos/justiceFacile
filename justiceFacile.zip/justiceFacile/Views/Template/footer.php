<footer>
    <!-- <div class="footer__links__wrapper">
        <a href="http://">Mentions légales</a>
        <a href="#">Contact</a>
    </div> -->
    <div class="footer__copyright__wrapper">
        <p>&copy; Justice facile <?= date("Y") ?></p>
    </div>
</footer>