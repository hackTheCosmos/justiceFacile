<div class="bars__header__wrapper">
    <h1>Rechercher un barreau</h1>
    <div class="bars__search__wrapper">
        <div class="input__wrapper">
            <input class ="input" type="text" name="bars" placeholder="Ville" id = "bars__search__input">
            <div id="city__bars__search__results"></div>
        </div>
        <div class="input__wrapper">
            <input class ="inpu submit__input" type="submit" name="search" id="submit__bars__search__input" value = "Rechercher"> 
        </div>
    </div>
</div>

<div id="bars__search__results__global__wrapper">
    
</div>