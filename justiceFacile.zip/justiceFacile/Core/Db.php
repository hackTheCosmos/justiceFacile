<?php

namespace App\Core;

use PDO;
use PDOException;

/**
 * Singleton qui permet de se connecter à la base de données
 */
class Db extends PDO 
{
    // Instance unique de la class Db
    private static $instance;

    // Informations de connexion à la base de données
    private const DBHOST = "localhost";
    private const DBUSER = "root";
    private const DBPASS = "";
    private const DBNAME = "justice_facile";

    /**
     * Constructeur du singleton permettant de se connecter à la base de données
     */
    public function __construct()
    {
        // DSN de connexion
        $dsn = "mysql:dbname=".self::DBNAME.";host=".self::DBHOST;

 
        try {
            // On appelle le constructeur de PDO
            parent::__construct ($dsn, self::DBUSER, self::DBPASS, array(1002 => 'SET NAMES utf8'));
            // on défini les attributs de PDO pour paramétrer toutes les caractéristiques de PDO que l'on souhaite utiliser
            $this->setAttribute(PDO::MYSQL_ATTR_INIT_COMMAND, "SET NAMES utf8");
            $this->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            $this->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    /**
     * Permet de créer une instance unique de Db
     *
     * @return self
     */
    public static function getInstance(): self
    {
        if(self::$instance === null) 
        {
            self::$instance = new self;
        }
        return self::$instance;
    }
}